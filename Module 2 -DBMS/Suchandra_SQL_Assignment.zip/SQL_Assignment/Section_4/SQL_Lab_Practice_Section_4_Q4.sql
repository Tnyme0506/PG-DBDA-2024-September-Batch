# 4. Drop index of table emp

drop index emp_index on emp;