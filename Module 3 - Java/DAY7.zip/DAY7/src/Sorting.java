
public class Sorting
{

	 static void sort(int[] mark)
	{
		System.out.println("sorting of integer array");
	}
	
	 static void sort(String[] sub)
		{
			System.out.println("sorting of String array");
		}
}
