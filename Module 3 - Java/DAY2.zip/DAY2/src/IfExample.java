
public class IfExample
{

	public static void main(String[] args) 
	{
	
		int num = 21;
		
		if(num%2 ==0)
		{
			System.out.println("given number  "+ num + " is   Even");
		}else
		{
			System.out.println("given number  "+ num + " is   odd");
		}
		
				
	}
	
}
