# 8. Create a temporary table test
create temporary table test(
		id int)