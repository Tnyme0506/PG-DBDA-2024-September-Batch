# 15. List the employees who are drawing basic pay not equal to 12400

select * from emp 
where emp.basicpay != 12400