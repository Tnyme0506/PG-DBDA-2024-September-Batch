
public class Testencapsulation
{

	public static void main(String[] args) 
	{
	
		
		Emp e = new Emp();
		e.reademp();
		e.dispemp();
		
		
	}
	
	
}
