
public class TestStatic
{

	public static void main(String[] args) 
	{
		
		int reserve =MethodExample2.reverse(3456);
		System.out.println(reserve);
		
		System.out.println("in teststatic class");
		
	}
	
}
