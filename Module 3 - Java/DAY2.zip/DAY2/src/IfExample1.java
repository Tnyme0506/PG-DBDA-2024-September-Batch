
public class IfExample1
{

public static void main(String[] args) 
{

	int lab = 10;
	int ccee = 30;
	
	if((lab>16) || (ccee>16))
	{
	System.out.println("result = pass");	
	}
	else
		
		System.out.println("result = fail");	
	
}

}
