import java.util.Arrays;
import java.util.Collections;

public class TestOverloaing
{
	public static void main(String[] args) 
	{
	
		       int[] m = {50,20,100,30};
		       Arrays.sort(m);
		       System.out.println("after sorting");
		       for(int ele :m)
		       {
		    	   System.out.println(ele);
		       }

		      String[] s = {"c++","java","dbt"};
		      Arrays.sort(s);
	}
	
}
