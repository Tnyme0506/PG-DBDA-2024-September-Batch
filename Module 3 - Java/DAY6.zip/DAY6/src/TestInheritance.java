
public class TestInheritance 
{

	public static void main(String[] args) 
	{
		
//		A a = new A();
//		a.i = 10;
//		a.displayA();
		
		
//		B b= new B();
//		b.j =20;
//		b.displayB();
//		
//		b.i = 10;
//		b.displayA();
		
//		C c = new C();
//		c.k =30;
//		c.showC();
//		
//		c.j = 20;
//		c.displayB();
//		
//		c.i =10;
//		c.displayA();
//		
		
//	B b = new B();
//	b.i =10;
//	b.j = 20;
//	b.displayA();
//	b.displayB();
		
		
	C c = new C();
	c.k = 30;
	c.showC();
	c.i = 10;
	c.displayA();
		
		
		
	}
}
