# 4. List the employees who are not having any superior to work under

select *
from emp
where supcode  is null