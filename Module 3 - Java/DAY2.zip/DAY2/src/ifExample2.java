
public class ifExample2
{

	public static void main(String[] args) 
	{
	
		int per = 65;
		
		if(per>90)
			System.out.println("grade = A");
		else if(per>80)
			System.out.println("grade = B");
		else if(per>60)
			System.out.println("grade = C");
		else if(per>50)
			System.out.println("grade = D");
		else
			System.out.println("grade = F");
		
		
		
		
		
		
	} 
	
	
	
}
