import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Stack;

public class testinterface
{

	public static void main(String[] args) 
	{
	
		LinkedList ll = new LinkedList();
		ll.add(10);
		ll.add(20);
		ll.add(30);
		ll.add(40);
		
		
	}
	
}
