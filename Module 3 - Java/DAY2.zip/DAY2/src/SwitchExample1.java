
public class SwitchExample1 
{

	public static void main(String[] args) 
	{
	
		String cname= "DBDA";
		
		switch(cname)
		{
		case "DAC":System.out.println("70% placement");
		break;
		case "DBDA":System.out.println("80% placement");
		break;
		case "DESD":System.out.println("75% placement");
		break;
		default:System.out.println("invalid input");
		break;
		
		}
		
		
		
	}
	
}
