
public class WhileExample
{

	public static void main(String[] args) 
	{
	
//		int i =0;
//		while(i<10)
//		{
//			System.out.println('*');
//			i++;
//			
//		}
		
		
//		int num = 1234;
//		int digit;
//		while(num>0)
//		{					
//			digit = num%10;
//			System.out.print(digit);
//			num = num/10;
//			
//		}
			
		int num = 1234;
		int digit;
		do
		{					
			digit = num%10;
			System.out.print(digit);
			num = num/10;
			
		}while(num>0);
		
		
		
		
	}
	
	
}
