# 37. Display the employee names in full uppercase. 
select upper(emp.empname) as 'Employee_Name' from emp 
