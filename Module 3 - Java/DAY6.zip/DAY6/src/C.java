
public class C extends A 
{
	int k;
	
	void showC()
	{
		System.out.println(k);
	}
	
}
