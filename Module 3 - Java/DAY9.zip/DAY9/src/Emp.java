
public class Emp 
{

	private int id;
	private String name;
	
	
	void reademp()
	{
		id = 1001;
		name = "shan";
	}
	
	void dispemp()
	{
		System.out.println(id+name);
	}
	
}
