# 6. Create a temporary table student with field with filed id, name, age, gender

create temporary table student(
		id int,
        name varchar(100),
        age int,
        gender varchar(10))
