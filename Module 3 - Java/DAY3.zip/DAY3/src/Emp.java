
public class Emp
{

	public void empGetno()
	{
		System.out.println("1003");
	}
	
}
	