# 14. List the youngest employee of the office

select *
from emp
order by birthdate desc
limit 1

