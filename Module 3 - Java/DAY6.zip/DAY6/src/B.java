
public class B extends A
{

	int j;
	
	public void displayB()
	{
		System.out.println(j);
	}
}
