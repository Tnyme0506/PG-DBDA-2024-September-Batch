# 2. List all the departments and the budgets
select dept.deptname as Departments, dept.budget as Budget
from dept