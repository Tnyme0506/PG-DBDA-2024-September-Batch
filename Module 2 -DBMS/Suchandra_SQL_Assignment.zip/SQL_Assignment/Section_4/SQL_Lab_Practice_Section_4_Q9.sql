# 9. Drop temporary table test
drop temporary table test