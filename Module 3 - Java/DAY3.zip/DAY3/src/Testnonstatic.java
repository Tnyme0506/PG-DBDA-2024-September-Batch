
public class Testnonstatic 
{

	public static void main(String[] args) 
	{
		Emp e = new Emp();
		
		e.empGetno();
		
	}
}

	

