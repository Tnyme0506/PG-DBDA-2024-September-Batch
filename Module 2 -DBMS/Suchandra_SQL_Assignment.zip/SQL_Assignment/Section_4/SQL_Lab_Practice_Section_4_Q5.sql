# 5. Find all the index of table dept

show index from dept