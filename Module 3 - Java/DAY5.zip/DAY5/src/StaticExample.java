
public class StaticExample 
{

	 static int i;
	
	public static void increment()
	{
		
		System.out.println(++i);
	
	}
	
	public static void main(String[] args)
	{
	
		
		StaticExample.increment();
		
		StaticExample.increment();
		
		StaticExample.increment();
		
		
		
	}
	
}
