# 2. Create unique index dept_index on table dept on the field deptname.

Create unique index dept_index on dept(deptname);