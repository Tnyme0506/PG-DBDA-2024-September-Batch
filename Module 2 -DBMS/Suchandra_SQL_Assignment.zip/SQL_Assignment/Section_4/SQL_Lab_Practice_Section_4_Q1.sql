# 1. Create emp_index on table emp on the field birthdate.

create index emp_index on emp(birthdate);
