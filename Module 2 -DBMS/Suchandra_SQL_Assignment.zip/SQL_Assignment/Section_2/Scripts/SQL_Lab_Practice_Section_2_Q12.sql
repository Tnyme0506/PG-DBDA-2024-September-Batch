# 12. List the employees working for ‘accounts’ and ‘personal’ department

select *
from emp
where emp.deptcode = 'ACCT' and 'PERS'