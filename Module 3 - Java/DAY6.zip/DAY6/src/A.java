
public class A 
{
   int i;
   
   public void displayA()
   {
	   System.out.println(i);
   }
	
}
